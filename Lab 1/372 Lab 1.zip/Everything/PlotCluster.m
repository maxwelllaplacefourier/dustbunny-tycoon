function [ output_args ] = PlotCluster( input_args )
%PLOTCLUSTER Summary of this function goes here
%   Detailed explanation goes here


end
